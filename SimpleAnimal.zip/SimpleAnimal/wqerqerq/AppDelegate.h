//
//  AppDelegate.h
//  wqerqerq
//
//  Created by ADC on 2017/12/14.
//  Copyright © 2017年 ADC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

