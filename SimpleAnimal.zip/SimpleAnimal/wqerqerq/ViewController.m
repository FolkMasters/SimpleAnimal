//
//  ViewController.m
//  wqerqerq
//
//  Created by ADC on 2017/12/14.
//  Copyright © 2017年 ADC. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIScrollViewDelegate>
@property (nonatomic, strong)UIView *bottomView;
@property (nonatomic, strong)UILabel *nameLable;
@property (nonatomic, strong)UILabel *titielLable;
@property (nonatomic, copy)NSArray *values;
@property (nonatomic,strong) UIScrollView *scroViewG;
@property (nonatomic,strong) UIView *cView;
@property (nonatomic,strong) NSTimer *rotateTimer;
@property (nonatomic, copy)NSArray *colors;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.values = @[
                    @"1手机客户挖掘和人口和会计同行我看人浩特认为我我入微透肉无投入人均可我会离开任何来看太好玩了狂热建设路口人家说；金融我今天",
                    @"2爱的发达地方",
                    @"3啊",
                    @"4爱的发的发放到发放大发大发大发大发大发发发打发打发打发打发爱的发的发放到发放大发大发大发大发大发发发打发打发打发打发爱的发的发放到发放大发大发大发大发大发发发打发打发打发打发爱的发的发放到发放大发大发大发大发大发发发打发打发打发打发爱的发的发放到发放大发大发大发大发大发发发打发打发打发打发爱的发的发放到发放大发大发大发大发大发发发打发打发打发打发",
                    @"5爱的发的发发发发打发打发打发打发"];
    [self.view addSubview:self.bottomView];
//    [self.bottomView addSubview:self.titielLable];
    [self.bottomView addSubview:self.nameLable];
    
    self.navigationController.navigationBar.backgroundColor = [[UIColor blueColor] colorWithAlphaComponent:0.5];
//    self.title = @"大喊大叫看";
    [self.navigationController.navigationBar addSubview:self.titielLable];
//    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.center.mas_equalTo(self.view);
//    }];
    
    NSArray *colors = @[[UIColor redColor],[UIColor greenColor]];
    self.colors = colors;
    NSInteger count = colors.count+1;
    
    
    UIScrollView *scroView =[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 300, 100)];
    [scroView setContentSize:CGSizeMake(300, 100*count)];
    scroView.delegate =self;
    scroView.center = self.view.center;
    [self.view addSubview:scroView];
    scroView.pagingEnabled = YES;
    self.scroViewG = scroView;
    
    for (int i = 0; i<colors.count+1; i++) {
        UIView *view =[[UIView alloc]initWithFrame:CGRectMake(0, i*100, 300, 100)];
        [scroView addSubview:view];
        if (i==colors.count) {
            view.backgroundColor = colors[0];
        }else{
            view.backgroundColor = colors[i];
        }
    }
    self.rotateTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(changeView) userInfo:nil repeats:YES];

}


- (void)changeView{
    //得到scrollView
    UIScrollView *scrollView = self.scroViewG;
    //通过改变contentOffset来切换滚动视图的子界面
    float offset_Y = scrollView.contentOffset.y;
    //每次切换一个屏幕
    offset_Y += 100;
    
    //得到最终的偏移量
    CGPoint resultPoint = CGPointMake(0, offset_Y);
    //切换视图时带动画效果
    //最右边的多余视图实际上就是第一个视图，现在是要从第一个视图向第二个视图偏移，所以偏移量为一个屏幕宽度
    if (offset_Y > 100*self.colors.count) {
        [scrollView setContentOffset:resultPoint animated:YES];
        scrollView.contentOffset = CGPointMake(0, 0);
        NSLog(@"2");
    }else{
        [scrollView setContentOffset:resultPoint animated:YES];
        NSLog(@"3");
    }

   
    
}

#pragma mark -- 滚动视图的代理方法
//开始拖拽的代理方法，在此方法中暂停定时器。
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    NSLog(@"正在拖拽视图，所以需要将自动播放暂停掉");
    //setFireDate：设置定时器在什么时间启动
    //[NSDate distantFuture]:将来的某一时刻
    [self.rotateTimer setFireDate:[NSDate distantFuture]];
}

//视图静止时（没有人在拖拽），开启定时器，让自动轮播
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    //视图静止之后，过1.5秒在开启定时器
    //[NSDate dateWithTimeInterval:1.5 sinceDate:[NSDate date]]  返回值为从现在时刻开始 再过1.5秒的时刻。
    NSLog(@"开启定时器");
    [self.rotateTimer setFireDate:[NSDate dateWithTimeInterval:1.5 sinceDate:[NSDate date]]];
}









-(void)updateLayout{
    __weak typeof(self)weakSelf = self;
    CGRect frame = self.navigationController.navigationBar.frame;
    [self.bottomView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(@(frame.size.height+frame.origin.y+10));
        make.centerX.mas_equalTo(weakSelf.view);
//        make.center.mas_equalTo(weakSelf.view);
        make.width.height.lessThanOrEqualTo(weakSelf.view).offset(-100);
    }];
//    [self.titielLable mas_remakeConstraints:^(MASConstraintMaker *make) {
//        make.bottom.greaterThanOrEqualTo(self.nameLable.mas_top);
//        make.top.greaterThanOrEqualTo(self.bottomView.mas_top);
//    }];
    
    [self.nameLable mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.bottomView).offset(10);
        make.right.mas_equalTo(weakSelf.bottomView).offset(-10);
        make.top.mas_equalTo(weakSelf.bottomView).offset(10);
        make.bottom.mas_equalTo(weakSelf.bottomView).offset(-10);
    }];
    
    
    // 告诉self.view约束需要更新
    [self.view setNeedsUpdateConstraints];
    // 调用此方法告诉self.view检测是否需要更新约束，若需要则更新，下面添加动画效果才起作用
    [self.view updateConstraintsIfNeeded];
    
    [UIView animateWithDuration:0.3 animations:^{
        [self.view layoutIfNeeded];
    }];
    
}

-(UIView *)bottomView{
    if (!_bottomView) {
        _bottomView =[[UIView alloc]init];
        _bottomView.backgroundColor =[[UIColor redColor] colorWithAlphaComponent:0.2];
    }
    return _bottomView;
}

- (UILabel *)nameLable {
    if (!_nameLable) {
        _nameLable = [[UILabel alloc] init];
        _nameLable.textAlignment = NSTextAlignmentCenter;
        _nameLable.userInteractionEnabled = YES;
        _nameLable.font = [UIFont systemFontOfSize:18];
        _nameLable.textColor = [UIColor blackColor];
        _nameLable.numberOfLines = 0;
    }
    return _nameLable;
}
- (UILabel *)titielLable {
    if (!_titielLable) {
        _titielLable = [[UILabel alloc] init];
        _titielLable.textAlignment = NSTextAlignmentCenter;
        _titielLable.userInteractionEnabled = YES;
        _titielLable.font = [UIFont systemFontOfSize:18];
        _titielLable.textColor = [UIColor blackColor];
        _titielLable.text = @"标题";
        [_titielLable sizeToFit];
//        _nameLable.numberOfLines = 0;
    }
    return _titielLable;
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSInteger index = arc4random()%5;
    self.nameLable.text = self.values[index];
    [self updateLayout];
    
}


@end
